Extensions
==========

peco
-----

If you have [peco](https://github.com/peco/peco), 
write `use "peco"` on your `.nyagos` to extend readline with power.

* `C-r` History
* `C-o` Filename completion
* `M-h` Directory history
* `M-g` Git-revision

cho
---

If you have [cho](https://github.com/mattn/cho), 
write `use "cho"` on your `.nyagos` to extend readline with power.

* `C-r` History
* `C-o` Filename completion
* `M-h` Directory history
* `M-g` Git-revision
