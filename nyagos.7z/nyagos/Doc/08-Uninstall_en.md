English / [Japanese](./08-Uninstall_ja.md)

Uninstall
---------

Remove unzipped files and `%APPDATA%\NYAOS.ORG` and icon on the desktop.
NYAGOS.exe writes nothing on registry.


