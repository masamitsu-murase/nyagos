[English](./08-Uninstall_en.md) / Japanese

アンインストール
----------------

UNZIP で展開されたファイルと %APPDATA%\NYAOS.ORG 以下、デスクトップ
アイコンを削除してください。NYAGOS.exe はレジストリを読み書きしません。

<!-- vim:set fenc=utf8: -->
