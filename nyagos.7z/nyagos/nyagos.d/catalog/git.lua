if not nyagos then
    print("This is a script for nyagos not lua.exe")
    os.exit()
end

local gitpath=share.gitpath

-- hub exists, replace git command
local hubpath=nyagos.which("hub.exe")
if hubpath then
  nyagos.alias.git = "hub.exe"
end

share.git = {}

local getcommits = function(args)
    local fd=io.popen(gitpath .. " log --format=\"%h\" -n 10 2>nul","r")
    if not fd then
        return {}
    end
    local result={}
    for line in fd:lines() do
        result[#result+1] = line
    end
    fd:close()
    return result
end

local getremotes = function()
    local fd=io.popen(gitpath .. " remote 2>nul", "r")
    if not fd then
        return {}
    end
    local result={}
    for line in fd:lines() do
        result[#result+1] = line
    end
    fd:close()
    return result
end

-- setup local branch listup
local branchlist = function(args)
  if string.find(args[#args],"[\\\\]") then
      return nil
  end
  local gitbranches = {}
  local gitbranch_tmp = nyagos.eval(gitpath .. ' for-each-ref  --format="%(refname:short)" refs/heads/ 2> nul')
  for line in gitbranch_tmp:gmatch('[^\n]+') do
    table.insert(gitbranches,line)
  end
  return gitbranches
end

local unquote = function(s)
    s = string.gsub(s,'"','')
    return string.gsub(s,'\\[0-7][0-7][0-7]',function(t)
        return string.char(tonumber(string.sub(t,2),8))
    end)
end

local isUnderUntrackedDir = function(arg,files)
    local matched_count=0
    local last_matched
    local upper_arg = string.upper(arg)
    local upper_arg_len = string.len(upper_arg)
    for i=1,#files do
        if string.upper(string.sub(files[i],1,upper_arg_len)) == upper_arg then
            matched_count = matched_count + 1
            last_matched = files[i]
        end
    end
    if matched_count == 1 and string.match(last_matched,"/$") then
        return true
    elseif matched_count < 1 then
        return true
    end
    return false
end

local addlist = function(args)
    local fd = io.popen(gitpath .. " status -s 2>nul","r")
    if not fd then
        return nil
    end
    local files = {}
    for line in fd:lines() do
        local arrowStart,arrowEnd = string.find(line," -> ",1,true)
        if arrowStart then
            files[#files+1] = unquote(string.sub(line,4,arrowStart-1))
            files[#files+1] = unquote(string.sub(line,arrowEnd+1))
        else
            files[#files+1] = unquote(string.sub(line,4))
        end
    end
    fd:close()
    if isUnderUntrackedDir(args[#args],files) then
        return nil
    end
    return files
end

local checkoutlist = function(args)
    local result = branchlist(args) or {}
    local fd = io.popen(gitpath .. " status -s 2>nul","r")
    if fd then
        for line in fd:lines() do
            if string.sub(line,1,2) == " M" then
                result[1+#result] = unquote(string.sub(line,4))
            end
        end
        fd:close()
    end
    return result
end

local pushcompletion = function(args)
    if #args == 2 then
        return getremotes()
    elseif #args == 3 then
        return branchlist(args)
    else
        return nil
    end
end


--setup current branch string
local currentbranch = function()
  return nyagos.eval(gitpath .. ' rev-parse --abbrev-ref HEAD 2> nul')
end

-- subcommands
local gitsubcommands={}

-- keyword
gitsubcommands["bisect"]={"start", "bad", "good", "skip", "reset", "visualize", "replay", "log", "run"}
gitsubcommands["notes"]={"add", "append", "copy", "edit", "list", "prune", "remove", "show"}
gitsubcommands["reflog"]={"show", "delete", "expire"}
gitsubcommands["rerere"]={"clear", "forget", "diff", "remaining", "status", "gc"}
gitsubcommands["stash"]={"save", "list", "show", "apply", "clear", "drop", "pop", "create", "branch"}
gitsubcommands["submodule"]={"add", "status", "init", "deinit", "update", "summary", "foreach", "sync"}
gitsubcommands["svn"]={"init", "fetch", "clone", "rebase", "dcommit", "log", "find-rev", "set-tree", "commit-diff", "info", "create-ignore", "propget", "proplist", "show-ignore", "show-externals", "branch", "tag", "blame", "migrate", "mkdirs", "reset", "gc"}
gitsubcommands["worktree"]={"add", "list", "lock", "prune", "unlock"}

-- branch
gitsubcommands["branch"]=branchlist
gitsubcommands["checkout"]=branchlist
gitsubcommands["reset"]=branchlist
gitsubcommands["merge"]=branchlist
gitsubcommands["rebase"]=branchlist
gitsubcommands["revert"]=branchlist
gitsubcommands["switch"]=branchlist

gitsubcommands["show"]=getcommits

gitsubcommands["add"]=addlist
gitsubcommands["restore"]=addlist
gitsubcommands["push"]=pushcompletion
gitsubcommands["fetch"]=pushcompletion
gitsubcommands["pull"]=pushcompletion


local gitvar=share.git
gitvar.subcommand=gitsubcommands
gitvar.branch=branchlist
gitvar.currentbranch=currentbranch
share.git=gitvar

if not share.maincmds then
    use "subcomplete.lua"
end

if share.maincmds and share.maincmds["git"] then
    -- git command complementation exists.
    nyagos.complete_for.git = function(args)
        while #args > 2 and args[2]:sub(1,1) == "-" do
            table.remove(args,2)
        end
        if #args == 2 then
            return share.maincmds.git
        end
        local subcmd = table.remove(args,2)
        while #args > 2 and args[2]:sub(1,1) == "-" do
            table.remove(args,2)
        end
        local t = share.git.subcommand[subcmd]
        if type(t) == "function" then
            return t(args)
        elseif type(t) == "table" and #args == 2 then
            return t
        end
    end
end

-- EOF
